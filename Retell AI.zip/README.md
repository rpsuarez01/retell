# Retell → Airtable Bridge (Vercel version)

Two serverless functions, no server to keep running yourself:
- `api/retell-call.js` → post-call logging into your Calls table
- `api/retell-booking.js` → live create_booking function target, into your Bookings table

## Deploy steps

1. Push this folder to a GitHub repo (Vercel deploys from a repo, not a raw folder
   upload, in the standard flow).
2. Go to vercel.com → **Add New → Project** → import that repo.
3. Vercel auto-detects the `api/` folder — no build config needed for this project.
4. Before deploying, add your environment variables under **Settings → Environment
   Variables**:
   - `AIRTABLE_API_KEY`
   - `AIRTABLE_BASE_ID`
   - `AIRTABLE_CALLS_TABLE` (optional, defaults to "Calls")
   - `AIRTABLE_BOOKINGS_TABLE` (optional, defaults to "Bookings")
5. Click **Deploy**. You'll get a URL like `https://your-project.vercel.app`.

## Your two webhook URLs, once deployed
- Retell agent's **Webhook URL** setting → `https://your-project.vercel.app/api/retell-call`
- `create_booking` function's **endpoint** → `https://your-project.vercel.app/api/retell-booking`

## Testing without deploying yet
Run `vercel dev` locally (after `npm install -g vercel` and `vercel login`) to test
these functions on localhost before pushing live.

## Note on Node's built-in fetch
This uses the native `fetch` available in Node 18+, which is what Vercel's default
runtime uses — no extra HTTP library needed.
