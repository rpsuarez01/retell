const AIRTABLE_BASE_ID = process.env.AIRTABLE_BASE_ID;
const AIRTABLE_API_KEY = process.env.AIRTABLE_API_KEY;

function airtableUrl(table) {
  return `https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${encodeURIComponent(table)}`;
}

async function airtableCreate(table, fields) {
  const res = await fetch(airtableUrl(table), {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${AIRTABLE_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ fields, typecast: true }),
  });
  const data = await res.json();
  if (!res.ok) {
    console.error('Airtable create failed:', data);
    throw new Error(JSON.stringify(data));
  }
  return data;
}

module.exports = { airtableCreate };
