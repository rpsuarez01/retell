const { airtableCreate } = require('../lib/airtable');

const BOOKINGS_TABLE = process.env.AIRTABLE_BOOKINGS_TABLE || 'Bookings';

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const args = req.body.args || req.body;

    const fields = {
      'Customer Name': args.customer_name || '',
      'Phone': args.phone || '',
      'Service Address': args.service_address || '',
      'Owner/Tenant/Property Manager': args.owner_or_tenant || '',
      'New/Existing Customer': args.new_or_existing_customer || '',
      'Equipment Type': args.equipment_type || '',
      'Brand': args.brand || '',
      'Age': args.equipment_age || '',
      'Problem Description': args.problem_description || '',
      'Symptom Details': args.symptom_details || '',
      'Onset/Duration': args.onset_duration || '',
      'Prior Troubleshooting': args.prior_troubleshooting || '',
      'Vulnerable Occupant': !!args.vulnerable_occupant,
      'Priority Level': args.priority_level || '',
      'Access Notes': args.access_notes || '',
      'Appointment Date': args.appointment_date || '',
      'Appointment Window': args.appointment_window || '',
      'Booking Status': 'Confirmed',
    };

    const record = await airtableCreate(BOOKINGS_TABLE, fields);

    res.status(200).json({
      success: true,
      booking_id: record.id,
      message: 'Booking created successfully.',
    });
  } catch (err) {
    console.error('Error handling create_booking webhook:', err);
    res.status(500).json({ success: false, message: 'Failed to create booking.' });
  }
};
