const { airtableCreate } = require('../lib/airtable');

const CALLS_TABLE = process.env.AIRTABLE_CALLS_TABLE || 'Calls';

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Acknowledge fast — Retell retries if this takes too long.
  res.status(200).json({ received: true });

  try {
    const { event, call } = req.body;
    if (event !== 'call_analyzed') return;

    const analysis = call.call_analysis || {};
    const custom = analysis.custom_analysis_data || {};

    const fields = {
      'Call ID': call.call_id,
      'Timestamp': call.start_timestamp
        ? new Date(call.start_timestamp).toISOString()
        : new Date().toISOString(),
      'Caller Phone': call.from_number || '',
      'Route Type': custom.route_type || '',
      'Call Status': analysis.call_successful ? 'Completed' : 'Escalated',
      'Transcript': call.transcript || '',
    };

    const record = await airtableCreate(CALLS_TABLE, fields);
    console.log('Logged call to Airtable:', record.id);
  } catch (err) {
    console.error('Error handling call_analyzed webhook:', err);
  }
};
